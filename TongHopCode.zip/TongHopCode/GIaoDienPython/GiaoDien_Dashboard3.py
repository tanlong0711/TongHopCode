# Import the required libraries
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import serial
import time

ser = serial.Serial('COM5', 115200)

def docViet():
#    ser.write(b'32767')
    S1 = ser.readline()
    S2=S1.decode()
    if S2!='':
        if (len(S2)<10):
            S3=S2[3:7]
            S4=S2[0:3]
            print(S2)
            print("Ket thuc")
            if S4=="171":
                Label7=Label(win, text=S3, font= ('Aerial 40 bold'),fg='red',bg='lightblue')
                Label7.place(x=600,y=550)
            if S4=="187":
                Label8=Label(win, text=S3, font= ('Aerial 40 bold'),fg='red', bg='lightblue')
                Label8.place(x=980,y=550)
 
    button4.after(10,docViet)
    

def start():
    print('START')
    ser.write(b'1')
    time.sleep(0.01)
    #messagebox.showinfo("Message","BẬT ĐÈN")
    Label4=Label(win, text="             ", font= ('Aerial 20 bold'), fg='red', bg='light blue')
    Label4.place(x=120,y=550)
    Label4=Label(win, text="Nguồn: ON", font= ('Aerial 20 bold'), fg='red', bg='light blue')
    Label4.place(x=120,y=550)

    
def stop():
    print('STOP')
    ser.write(b'2')
    time.sleep(0.01)
    #messagebox.showinfo("Message","TẮT ĐÈN")
    Label4=Label(win, text="             ", font= ('Aerial 20'),bg="lightblue")
    Label4.place(x=120,y=550)
    Label4=Label(win, text="Nguồn: OFF", font= ('Aerial 20'),bg="lightblue")
    Label4.place(x=120,y=550)

def HV_ON():
    print('HV_ON')
    ser.write(b'3')
    time.sleep(0.01)
    #messagebox.showinfo("Message","High Voltage: ON")
    Label5=Label(win, text="                  ", font= ('Aerial 20 bold'),fg='red', bg="lightblue")
    Label5.place(x=550,y=350)
    Label5=Label(win, text="High Voltage: ON", font= ('Aerial 20 bold'),fg='red', bg="lightblue")
    Label5.place(x=550,y=350)

def HV_OFF():
    print('HV_OFF')
    ser.write(b'4')
    time.sleep(0.01)
    #messagebox.showinfo("Message","High Voltage: OFF")
    Label5=Label(win, text="                    ", font= ('Aerial 20'), bg="lightblue")
    Label5.place(x=550,y=350)
    Label5=Label(win, text=" High Voltage: OFF", font= ('Aerial 20'), bg="lightblue")
    Label5.place(x=550,y=350)

def TAYGA_ON():
    print('TAYGA_ON')
    ser.write(b'5')
    time.sleep(0.01)

def TAYGA_OFF():
    print('TAYGA_OFF')
    ser.write(b'6')
    time.sleep(0.01)    
    
# Create an instance of tkinter frame
win= Tk()

# Set the size of the tkinter window
win.geometry("1200x700")
win.title("Bảng điều khiển - Designed by LTP")

# Add an optional Label widget
Label(win, text= "BẢNG ĐIỀU KHIỂN MOTOR - DASHBOARD", font= ('Aerial 30 bold'),fg='blue').pack(pady= 60)

#Them logo khoa CKD
photo_image = PhotoImage(file="logoCKD.PNG")
LogoCKD1 = Label(win, image=photo_image)
LogoCKD1.place(x=50,y=20)

# Create a Button to display the message
BangDK1 = Canvas(win, bg="lightblue", height=400, width=260)
BangDK1.place(x=80, y=220)

BangDK2 = Canvas(win, bg="lightblue", height=200, width=395)
BangDK2.place(x=480, y=220)

lineTieuDe = Canvas(win, bg="lightblue", height=5, width=1300)
lineTieuDe.place(x=10, y=150)

Label3=Label(win, text="MAIN SWITCH", font= ('Aerial 20'))
Label3.place(x=110,y=180)

button1=Button(win, text= "START", font= ('Aerial 40'), bg='green', command=start)
button1.place(x=100,y=250)

button2=Button(win, text= "STOP",font= ('Aerial 40'),bg='red', command=stop)
button2.place(x=110,y=400)


Label2=Label(win, text="CUNG CẤP ĐIỆN ÁP CAO", font= ('Aerial 20'))
Label2.place(x=500,y=180)

button3=Button(win, text= "BẮT ĐẦU",font= ('Aerial 20 bold'),bg='green', command=HV_ON)
button3.place(x=500,y=250)

button4=Button(win, text= "KẾT THÚC",font= ('Aerial 20 bold'),bg='red', command=HV_OFF)
button4.place(x=700,y=250)

Label4=Label(win, text="Nguồn: OFF", font= ('Aerial 20'), bg='lightblue')
Label4.place(x=120,y=550)

Label5=Label(win, text=" High Voltage: OFF", font= ('Aerial 20'), bg='lightblue')
Label5.place(x=550,y=350)

Label6=Label(win, text="TỐC ĐỘ ĐỘNG CƠ [RPM]", font= ('Aerial 20'))
Label6.place(x=500,y=500)

Label9=Label(win, text="MOMENT XOẮN [N.M]", font= ('Aerial 20'))
Label9.place(x=900,y=500)

HienThi1 = Canvas(win, bg="lightblue", height=80, width=320)
HienThi1.place(x=510, y=540)

HienThi2 = Canvas(win, bg="lightblue", height=80, width=270)
HienThi2.place(x=905, y=540)

Labe20=Label(win, text="TAY GA", font= ('Aerial 20'))
Labe20.place(x=950,y=180)

button5=Button(win, text= "ON",font= ('Aerial 15 bold'),bg='green', command=TAYGA_ON)
button5.place(x=950,y=250)

button6=Button(win, text= "OFF",font= ('Aerial 15 bold'),bg='red', command=TAYGA_OFF)
button6.place(x=1050,y=250)

#Tao 1 nut ao, de thuc hien lenh
button4=Button(win, text= " ",font= ('Aerial 20 bold'),bg='green')
button4.after(10,docViet) #Thời gian đủ dài để khởi tạo kết nối nối tiếp

win.mainloop()
